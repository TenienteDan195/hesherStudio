This template / effect / code has been created by Mateus Generoso.
You can customize and check it out on its original site on the following link:
https://codepen.io/mtsgeneroso/pen/mdJRpxX

Thank you